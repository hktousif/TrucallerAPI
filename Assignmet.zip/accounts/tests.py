from django.test import TestCase

# Create your tests here.
from rest_framework import status
from rest_framework.test import APITestCase


class RegistrationTestCase(APITestCase):
    def test_registration(self):
        data = {
            "username": "9731174558",
            "email": "acs@gmail.com",
            "password1": "LovrMy52",
            "password2": "LovrMy52",
            "name": "Tousif",
        }
        response = self.client.post("/accounts/registration/", data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
